package br.ucsal.lista13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lista13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
